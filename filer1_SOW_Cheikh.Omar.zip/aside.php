<?php
    echo "<div id=\"box_aside\" class=\"recherche_p\">
                        <div id=\"description\">
                            <img id='img_aside' src=\"img/cos.jpg\" alt=\"lom\">
                            <div id=\"description_admin\">
                                <h3>Cheikh Omar SOW</h3>
                                <img src=\"img/student.png\" alt=\"php\">
                                <p>Je suis étudiant à Sup'Internet. J'aime l'informatique et les nouvelles technologies</p>
                            </div>
                        </div>
                    </div>";
?>