<?php
    echo "<header>
                <span><a href=\"index.php\">COS Filer </a></span>
                <nav>
                    <ul>
                        <li><a href=\"index.php\">Accueil</a></li>
                        <li><a href=\"my_files.php\">Mes fichiers</a></li>
                        <li><a id='in' href=\"auth.php\"><img src='img/login.png' alt='exit'/></a></li>
                    </ul>
                </nav>
            </header>";

    ?>